# 介绍
- 基于mitmproxy的代理扫描器
- 使用(参考start.sh)
    - 安装mitmproxy
    - 开启代理: mitmdump -k -q -p 8881 -s mitmscan.py
    - 开启扫描: python3 scanner.py
    - 浏览器配置代理http://127.0.0.1:8881，接着访问http://mitm.it安装https证书，然后就可以边上网边发现漏洞

# 详情
- mitmscan.py: mitmproxy插件, 解析http raw包
    - 插件将http raw包格式化为http json包
    ```
    {
        "url": "",//带参数的url
        "params": {},//get 参数
        "method": "", //post | get | ...
        "data": {},//{} | []  格式化后的body
        "body": "",//原始body
        "type": "", // multipart, form, json, plain，binary
        "headers": {},
        "cookies": {}
    }
    ```

- scanner.py: 读取http json包，调用poc扫描
    - python scanner.py -h

- poc编写：[参考](poc/ssrf.py)
    - 处理参数可以参考walkjson函数，递归遍历多层json，`一次性把所有value插入payload，减少请求量`
    - type是multipart和form 格式化后的body是一维的dict，value值可能存在base64json和字符串json
    - type为json时，格式化后的body可能是多维list或dict
    - 一维json: {'k1':'v1', 'k2':'v2'}
    - 多维json: {'k1':'v1', 'k2':{'k3':'v3'}, 'k4': ['v4', 2, 'v5']}

- json2http.html：http raw包与http json包互转

# 坑
- python传参都是传址，需要deepcopy之后扫描
- 传址式传参方便递归修改多层json
- poc插入payload又需要保留原值的时候，需要注意str+int会出错
- 运行路径问题，相对路径行不通