#coding:utf8
import mitmproxy.http
from mitmproxy import ctx, http
import time
import os, json
import urllib.parse

def is_binary_string(data):
    text_chars = bytearray({7, 8, 9, 10, 12, 13, 27} | set(range(0x20, 0x100)) - {0x7f})
    """
    https://stackoverflow.com/questions/898669/how-can-i-detect-if-a-file-is-binary-non-text-in-python
    """
    return bool(data.translate(None, text_chars))

class PacketSaver:
    def __init__(self):
        absdir = os.path.dirname(os.path.abspath(__file__))
        self.logdir = absdir+'/logs'
        if not os.path.exists(self.logdir):
            os.makedirs(self.logdir)
        self.outname = ''
        self.outbuffer = []

        self.black_mime = [
            'webp', 'jpg', 'jpeg', 'png', 'js', 'css', 'mp3', 'mp4', 'gif', 'ico', 'm3u8', 'woff', 'ttf'
        ]

    def request(self, flow: mitmproxy.http.HTTPFlow):
        request = flow.request
        metainfo = {}
        metainfo['url'] = request.url
        
        #filter url
        if not metainfo['url'].startswith('http'):
            return
        for e in self.black_mime:
            if metainfo['url'].endswith('.'+e):
                ctx.log.info('media file '+request.url)
                return
        #filter url end

        metainfo['method'] = request.method.lower()
        metainfo['params'] = {name: value for name, value in request.query.fields}
        metainfo['cookies'] = {name: value for name, value in request.cookies.fields}
        #remove cookies from header
        metainfo['headers'] = {name.lower(): value for name, value in request.headers.items() if name.lower() != 'cookie'}
        
        body = {}
        typess = ''
        if metainfo['method'] == 'get':
            typess = 'get'
            body = {}

        else:
            content_type = request.headers.get('content-type', '').strip()
            if 'multipart/form-data' in content_type:
                typess = 'multipart'
                body = self.extract_multipart(request)
            elif 'application/x-www-form-urlencoded' in content_type:
                typess = 'form'
                body = self.extract_form(request)
            elif 'json' in content_type:
                typess = 'json'
                body = self.extract_json(request)
            else:
                typess, body = self.detect_body(request)
        
        metainfo['type'] = typess     
        metainfo['data'] = body
        
        # save to file
        try:
            self.outbuffer.append(json.dumps(metainfo))
        except Exception as e:
            ctx.log.error('json.dumps '+str(e)+metainfo['url'])

        if len(self.outbuffer) >= 40:
            self.outname = self.logdir+'/mitmlog'+str(time.time())
            with open(self.outname, 'a') as f:
                f.write("\n".join(self.outbuffer))
                f.close()
            # reset
            self.outbuffer = []

    def response(self, flow: mitmproxy.http.HTTPFlow):
        pass

    def http_connect(self, flow: mitmproxy.http.HTTPFlow):
        pass

    @staticmethod
    def extract_multipart(request):
        body = {}
        for name, value in request.multipart_form.fields:
            # only try decode with utf-8
            try:
                n = name.decode('utf-8')
            except:
                continue
            try:
                body[n] = value.decode('utf-8')
            except:
                pass
        return body

    @staticmethod
    def extract_form(request):
        return {name: value for name, value in request.urlencoded_form.fields}

    @staticmethod
    def extract_json(request):
        try:
            data = json.loads(request.text)
        except Exception:
            return {}
        return data

    def detect_body(self, request):
        if is_binary_string(request.raw_content):
            return 'binary', {}
        try:
            text = request.raw_content.decode('utf-8', errors='strict')
        except Exception:
            return 'binary', {}
        if (text.startswith('{') and text.endswith('}')) or (text.startswith('[') and text.endswith(']')):
            try:
                return 'json', json.loads(text)
            except Exception as e:
                ctx.log.error(f'json.loads error {e}, {request.url}')
                return 'plain', {}
        # application/x-www-form-urlencoded
        elif text.find('=') != -1 and not text.endswith('='):
            data = {}
            segments = text.rstrip('&').split('&')
            for segment in segments:
                params = segment.split('=')
                if len(params) == 2:
                    data[params[0]] = params[1]
            return 'form', data
        else:
            return 'plain', {}

    #mitmproxy last function
    def done(self):
        if not self.outbuffer:
            return
        self.outname = self.logdir+ '/mitmlog'+str(time.time())
        with open(self.outname, 'a') as f:
            f.write("\n".join(self.outbuffer))
            f.close()
        print('save to file '+self.outname)

addons = [
    PacketSaver()
]

#mitmdump -p 8881 -s mitmscan.py  --ssl-insecure -q
#mitmproxy -p 8881 -s mitmscan.py  --ssl-insecure
#mitmproxy -p 8881 -s mitmscan.py --mode socks5 
#shift+e  to see logs
#shift + select = copy
#q = return, Enter, Up, Down
#z = clear,  G = end, end/home