#coding:utf-8
import os, sys
import logging
import json
import time, datetime
import argparse
import zipfile
import threading
import urllib.parse
import importlib
import copy
import threading
import concurrent.futures
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
logging.getLogger("requests").setLevel(logging.WARNING)

class Scanner:
    def __init__(self, poc=''):
        absdir = os.path.dirname(os.path.abspath(__file__))
        self.singlepoc = poc
        self.pocmodule = []
        self.pocdir = absdir+'/poc/'
        self.logpath = absdir+'/logs/'
        self.statusfilename = absdir+'/scannerlog'
        self.resultfilename = absdir+'/scannerresult'
        if not os.path.exists(self.logpath):
            os.makedirs(self.logpath)
        self.statusfile = None
        self.scanret = []
        self.scanstatus = {}

    def loadPocModule(self):
        print('==loading poc')
        if self.singlepoc:
            self.poc = self.singlepoc.split(',')
        else:
            self.poc = []
        for p in os.listdir(self.pocdir):
            if p.endswith('.py'):
                try:
                    p = p[0:len(p)-3]
                    if self.poc and p not in self.poc:
                        continue
                    
                    module = importlib.import_module('poc.'+p)
                    self.pocmodule.append(module.Poc())
                except Exception as e:
                    print("poc module error "+str(e))
                    import traceback
                    traceback.print_exc()
                    
        #针对host的扫描暂时不区分
        for p in os.listdir(self.pocdir+'/perserver'):
            if p.endswith('.py'):
                try:
                    p = p[0:len(p)-3]
                    if self.poc and p not in self.poc:
                        continue
                    
                    module = importlib.import_module('poc.perserver.'+p)
                    self.pocmodule.append(module.Poc())
                except Exception as e:
                    print("poc module error "+str(e))
                    import traceback
                    traceback.print_exc()
    
    def writeStatus(self):
        print('==write status')
        if self.scanstatus:
            self.statusfile = open(self.statusfilename, 'w')
            self.statusfile.write(json.dumps(self.scanstatus))
            self.scanstatus = {}
            self.statusfile.close()

    def readStatus(self):
        print('==read status')
        try:
            content = open(self.statusfilename, 'r').read()
        except:
            content = ''

        if content:
            self.scanstatus = json.loads(content)
        for fn in os.listdir(self.logpath):
            if fn.startswith('mitmlog') and not fn in self.scanstatus.keys():
                self.scanstatus[fn] = 0

    def cleanRepeat(self, maplist):
        #uniq
        ret = []
        url = []
        for m in maplist:
            try:
                mj = json.loads(m)
            except:
                mj = {}
            u = mj.get('url')
            if u and u not in url and u.find('.gov.cn') == -1 and u.find('.12377.cn') == -1:
                ret.append(json.dumps(mj))
                url.append(u)
        return ret

    def scan(self):
        print('Use Ctrl+C to exit')
        import datetime
        while True:
            try:
                self.loadPocModule()
                self.readStatus()
                start = datetime.datetime.now()
                self.doScan()
                self.writeStatus()

                end = datetime.datetime.now()
                used = (end-start).seconds
                
                if used < 2:
                    print('sleeping')
                    time.sleep(60)
                else:
                    time.sleep(2)
            except KeyboardInterrupt:
                print('Ctrl+C exiting scan')
                self.writeStatus()
                self.writeResult()
                raise KeyboardInterrupt

    def writeResult(self):
        if self.scanret:
            with open(self.resultfilename, 'a') as f:
                out = "\n"+"\n".join(self.scanret)
                f.write(out)
                f.close()
                # reset
                self.scanret = []

    def doScan(self):
        print('==scanning')
        for k,v in self.scanstatus.items():
            #per file
            if v != 'done':
                print(k)
                content = []
                try:
                    with open(self.logpath+k, 'r') as f:
                        content = f.read().split('\n')
                except:
                    pass
                content = self.cleanRepeat(content)
                # scan
                self.pocCaller(copy.deepcopy(content))

                self.scanstatus[k] = 'done'
                self.writeResult()


    def pocCaller(self, content):
        for poc in self.pocmodule:
            #per poc
            try:
                with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                    future_to_ret = []
                    for c in content:
                        try:
                            c = json.loads(c)
                            future_to_ret.append(executor.submit(poc.verify, c))
                        except Exception as e:
                            print(str(e))

                    for future in concurrent.futures.as_completed(future_to_ret):
                        try:
                            # update result
                            if future.result():
                                self.scanret.append(future.result()[0].get('title'))
                        except Exception as exc:
                            print(' %s' % (exc))
            except KeyboardInterrupt:
                print('Ctrl+C exiting pocCaller')
                raise KeyboardInterrupt
            except Exception as e:
                print("poc call error "+str(e))
        
        return self.scanret

    def scanFile(self, files):
        #scan single file
        print('scan '+files)
        content = []
        with open(files, 'r') as f:
            content = f.read().split('\n')
        content = [c for c in content if c ]
        self.loadPocModule()
        print(self.pocCaller(content))


###########Scanner


def packPacket():
    #pack scanned logs/*
    scanstatus = {}
    with open('scannerlog', 'r') as f:
        content = f.read()
        if content:
            scanstatus = json.loads(content)
    topack = []
    for k,v in scanstatus.items():
        if v == 'done':
            topack.append(k)
    print('packing count '+str(len(topack)))
    packname = str(datetime.date.today())+'_'+str(len(topack))+'.zip'
    packfile = zipfile.ZipFile('logs/'+packname, 'a')
    for f in topack:
        if os.path.isfile('logs/'+f):
            packfile.write('logs/'+f, f)
    packfile.close()
    for f in topack:
        try:
            os.remove('logs/'+f)
            scanstatus.pop(f)
        except:
            pass
    with open('scannerlog', 'w') as f:
        f.write(json.dumps(scanstatus))
        f.close()
    print('Pack done')

def getMetainfo(urls):
    cont = {}
    found = False
    #metainfo
    try:
        cont = json.loads(urls)
        found = True
    except:
        pass
    if not found:
        if not os.path.exists('logs'):
            os.makedirs('logs')
        #或url
        for f in os.listdir('logs'):
            try:
                if f.startswith('mitmlog'):
                    with open('logs/'+f, 'r') as ff:
                        cc = ff.read().split('\n')
                        for i in cc:
                            if not i:
                                continue
                            ci = json.loads(i)
                            if urls in ci['url']:
                                print(i)
                                found =True
                                cont = ci
                                break
            except Exception as e:
                pass
                import traceback
                traceback.print_exc()
                break
            if found:
                break
    try:
        if not found:
            print('not found')
            return
        p = cont
        url = p['url']
        out = p.get('method') + ' '+ url +' HTTP/1.1\n'
        
        for k,v in p['headers'].items():
            out += k + ': ' +v +'\n'
        
        cookies = 'Cookie:'
        for k,v in p['cookies'].items():
            cookies += k + '=' +v +'; '
        out += cookies

        data = ""
        if p['type'] == 'form':
            for k,v in p['data'].items():
                data += k + '=' +v +'&'
            data = data.rstrip('&')
        elif p['type'] == 'json':
            data += json.dumps(p['data'])
        elif p['type'] == 'plain':
            if p.get('plain'):
                data += p.get('data').get('plain')

        if data:
            out +='\n\n' + data
        else:
            out += '\n\n'
        
        print(out)
    except Exception as e:
        import traceback
        traceback.print_exc()
        print('error')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='全自动扫描mitmscan.py插件保存的数据包(logs目录). 结果保存scannerresult')
    parser.add_argument("-a", "--auto", action="store_true", help="自动模式(默认)")
    parser.add_argument("-f", "--files", type=str, help="指定文件名")
    parser.add_argument("-p", "--pack", action="store_true", help="打包扫描过的文件")
    parser.add_argument("-u", "--url", type=str, help="根据url查找源包并解析")
    parser.add_argument("-s", "--poc", type=str, help="指定poc")
    args = parser.parse_args()

    if sys.version_info.major != 3:
        print('Run with python3')
        sys.exit()

    try:

        if args.url:
            getMetainfo(args.url)

        elif args.files:
            scan = Scanner(args.poc)
            scan.scanFile(args.files)
        
        elif args.pack:
            packPacket()

        else:
            scan = Scanner(args.poc)
            scan.scan()
    except KeyboardInterrupt:
        print('Ctrl+C exiting main')