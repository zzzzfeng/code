#coding: utf-8
import json
import time
import hashlib, random
import urllib.parse
import copy
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class Poc(object):

    def __init__(self):
        pass

    def sendreq(self, data, allow_redirects=True):
        j = {}
        typess = data.get('type')
        proxies = {}
        #proxies = {"http": "http://127.0.0.1:8881", "https": "http://127.0.0.1:8881"}
        j['url'] = data['url']
        j['method'] = data.get('method')
        j['headers'] = data.get('headers')
        j['cookies'] = data.get('cookies')
        #http2.0
        if ':authority' in  j['headers'].keys():
            j['headers']['authority'] =  j['headers'][':authority']
            j['headers'].pop(':authority')
        #

        if typess == 'json':
            j['json'] = data.get('data')
        elif typess == 'multipart':
            j['files'] = data.get('data')
        else:
            j['data'] = data.get('data')

        #默认会urlencode
        j['params'] = data.get('params')

        j['proxies'] = proxies
        j['verify'] = False
        j['timeout'] = 10
        j['allow_redirects'] = allow_redirects

        return requests.request(**j)


    #origin和referer都可能被检测；origin没有path； @、#等绕过没法用
    #  origin                         referer
    #http://www.xxmi.com             http://www.xxmi.com
    #http://www.xxmi.com             http://www.xxmi.com?www.mi.com
    #http://www.mi.com.evil.com      http://www.mi.com.evil.com
    #http://www.mi.com.evil.com      http://www.xxmi.com?www.mi.com
    #响应code==200
    def cookParam(self, mj):
        url = mj.get('headers').get('origin') or mj.get('headers').get('Origin')
        if not url:
            url = mj.get('headers').get('referer') or mj.get('headers').get('Referer')
        if not url:
            url = mj.get('url')
        newhost = []
        #只检测post请求?
        if True:
            temp = urllib.parse.urlparse(url)                   
            port = 0
            if temp.netloc.find(':') > -1:
                port = temp.netloc.split(':')[-1]
            
            if port == 0:
                hosts = temp.netloc.split('.')
                hosts[-2] = 'xx'+hosts[-2]
                newhost.append(['.'.join(hosts), '.'.join(hosts)])

                hosts = temp.netloc.split('.')
                hosts[-2] = 'xx'+hosts[-2]
                newhost.append(['.'.join(hosts), '.'.join(hosts)+'?'+temp.netloc])

                newhost.append([temp.netloc+'.evil.com', temp.netloc+'.evil.com'])

                hosts = temp.netloc.split('.')
                hosts[-2] = 'xx'+hosts[-2]
                newhost.append([temp.netloc+'.evil.com', '.'.join(hosts)+'?'+temp.netloc])
            else:
                hosts = temp.netloc.split('.')
                hosts[-1] = hosts[-1].split(':')[0]
                hosts[-2] = 'xx'+hosts[-2]
                newhost.append(['.'.join(hosts)+':'+port, '.'.join(hosts)+':'+port])

                hosts = temp.netloc.split('.')
                hosts[-1] = hosts[-1].split(':')[0]
                hosts[-2] = 'xx'+hosts[-2]
                newhost.append(['.'.join(hosts)+':'+port, '.'.join(hosts)+':'+port+'?'+temp.netloc])

                hosts = temp.netloc.split('.')
                hosts[-1] = hosts[-1].split(':')[0]
                newhost.append(['.'.join(hosts)+'.evil.com'+':'+port, '.'.join(hosts)+'.evil.com'+':'+port])

                hosts = temp.netloc.split('.')
                hosts[-1] = hosts[-1].split(':')[0]
                hosts[-2] = 'xx'+hosts[-2]
                newhost.append([temp.netloc.split(':')[0]+'.evil.com'+':'+port, '.'.join(hosts)+':'+port+'?'+temp.netloc])

        return newhost
        

    def verify(self, data):
        try:
            metainfo = data
            if not data.get('cookies'):
                return
            temp = urllib.parse.urlparse(metainfo['url'])
            newhost = self.cookParam(metainfo)
            for x in newhost:
                d = copy.deepcopy(metainfo)
                d['headers']['origin'] = temp.scheme + '://' + x[0]
                d['headers']['referer'] = temp.scheme + '://' + x[1]
                r = self.sendreq(d, False)
                header = False
                credentials = False
                if r:
                    if r.status_code == 200 and len(r.text) > 5:
                        for k,v in r.headers.items():
                            if k.lower() == 'access-control-allow-origin' and v == temp.scheme + '://' + x[0]:
                                header = True
                            elif k.lower() == 'access-control-allow-credentials' and v.lower() == 'true' :
                                credentials = True
                        
                        if header and credentials:
                            return [{
                                "title": "{} 存在cors漏洞".format(metainfo.get('url').split('?')[0]),
                                "desc":  "方式 {} 返回{}".format(temp.scheme + '://' + x[0], r.text[0:200]),
                                "request": metainfo,
                                "severity": "medium",
                            }]
                
        except:
            return False

if __name__ == '__main__':
    data = {"url": "https://widget.weibo.com/topics/topic_vote_base.php", "data": {"uid": "1709486153", "border": "0", "footbar": "1", "width": "821", "height": "559", "refer": "1", "filter": "0", "language": "zh_cn", "version": "eyJhIjoiaHR0cDovLyJ9", "dup": "0", "antispam": "0", "isOutTopicSearch": "0", "top_mblog": "H8gs8beQy", "isshowright": "1", "tag": "360%E6%8A%A2%E7%A5%A8%E7%8E%8B7%E4%BB%A3%2C%E5%BF%AB%E6%8A%A2%E7%A5%A8%E5%BF%AB%E5%9B%9E%E5%AE%B6%2C%E8%81%8A%E8%81%8A%E4%BD%A0%E7%9A%84%E6%98%A5%E8%BF%90%E6%95%85%E4%BA%8B", "og": "http%3A%2F%2F12306.360.cn%2F%3Ffrom%3Dweibo", "app_src": "5E3UYb", "r": "1566802460646"}, "method": "post", "cookies": {"YF-Widget-G0": "4a4609df0e4ef6187a7b4717d4e6cf12"}, "headers": {"host": "widget.weibo.com", "user-agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0", "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "accept-language": "en-US,en;q=0.5", "accept-encoding": "gzip, deflate, br", "referer": "http://12306.360.cn/", "connection": "keep-alive", "upgrade-insecure-requests": "1"}, "type": "form", "params": {}}

    print(Poc().verify(data))