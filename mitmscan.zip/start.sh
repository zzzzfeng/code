bin/mitmdump -k -q -p 8881 -s mitmscan.py &

echo Proxy listening on port 8881

python3 scanner.py