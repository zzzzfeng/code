/*
 * Copyright 2008 Android4ME
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	 http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package test;

import java.io.File;
import java.io.FileInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.xmlpull.v1.XmlPullParser;
import android.content.res.AXmlResourceParser;
import android.util.TypedValue;

public class ApkCook {
	static String critical = "***";
	static String DEFAULT_XML = "AndroidManifest.xml";
	public static void main(String[] arguments) {
		try {
			String filename = "";
			String xmlfile = "";
			boolean dumpAll = false;
			boolean onlyCritical = false;
			for(String t:arguments){
				if(t.equals("-a")){
					dumpAll = true;
				}
				if(t.equals("-s")){
					onlyCritical = true;
				}
				if(t.contains(".apk")){
					filename = t;
				}
				if(t.contains(".xml")){
					xmlfile = t;
				}
			}
			if(filename.equals("") && xmlfile.equals("")){
				log("Usage: java -jar apkcook.jar test.apk|test.xml [-a | -s]");
				return;
			}
			
			AXmlResourceParser parser=new AXmlResourceParser();
			if(xmlfile.equals("")){
				File apkFile = new File(filename);
				ZipFile file = new ZipFile(apkFile, ZipFile.OPEN_READ);
				ZipEntry entry = file.getEntry(DEFAULT_XML);
				parser.open(file.getInputStream(entry));
			}else{
				FileInputStream file = new FileInputStream(xmlfile);
				parser.open(file);
			}
			if(dumpAll){
				dumpXml(parser);
				return;
			}
			//##:�ָ�����  @@�ָ�С��
			//˳�������������ʱ�������ж���ʲô���
			//intent-filter/exported ������*
			//exported == false ������$
			//enabled ����!
			String mpackage = "pa@@";
			String permission = "pe@@";
			String activity = "ac@@";
			String service = "se@@";
			String receiver = "re@@";
			String provider = "pr@@";
			String application = "en@@";
			String tmpMain = "";
			
			String which = "";
				
			while (true) {
				int type=parser.next();
				if (type==XmlPullParser.END_DOCUMENT) {
					break;
				}
				switch (type) {
					
					case XmlPullParser.START_TAG:
					{
						if(parser.getName().equals("application")){
							boolean debuggable = false;
							boolean allowbackup = true;
							which = "application";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									application += getAttributeValue(parser,i)+"@@";
								}
								if(parser.getAttributeName(i).equals("debuggable")){
									if(getAttributeValue(parser,i).equals("true")){
										debuggable = true;
									}
								}
								if(parser.getAttributeName(i).equals("allowbackup")){
									if(getAttributeValue(parser,i).equals("false")){
										allowbackup = false;
									}
								}
							}
							if(debuggable){
								application += "debug@@";
							}
							if(allowbackup){
								application += "backup@@";
							}
							break;
						}else if(parser.getName().equals("uses-permission")){
							which = "uses-permission";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									permission += getAttributeValue(parser,i)+ "@@";
								}
							}
							break;
						}else if(parser.getName().equals("activity")){
							which = "activity";
							String tm = "";
							
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									tm = getAttributeValue(parser,i);
									tmpMain = getAttributeValue(parser,i);
								}
								if(parser.getAttributeName(i).equals("exported")){
									if(getAttributeValue(parser,i).equals("false")){
										activity += "$";
									}else{
										activity += "*";
									}
								}
								if(parser.getAttributeName(i).equals("enabled")){
									if(getAttributeValue(parser,i).equals("false")){
										activity += "!";
									}else{
										activity += "";
									}
								}
							}
							//��ǩǰ��˳��һ����������
							activity += tm+ "@@";
							break;
						}else if(parser.getName().equals("service")){
							which = "service";
							String tm = "";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									tm = getAttributeValue(parser,i);
									tmpMain = getAttributeValue(parser,i);
								}
								if(parser.getAttributeName(i).equals("exported")){
									if(getAttributeValue(parser,i).equals("false")){
										service += "$";
									}else{
										service += "*";
									}
								}
								if(parser.getAttributeName(i).equals("enabled")){
									if(getAttributeValue(parser,i).equals("false")){
										service += "!";
									}else{
										service += "";
									}
								}
							}
							service += tm+ "@@";
							break;
						}else if(parser.getName().equals("receiver")){
							which = "receiver";
							String tm = "";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									tm = getAttributeValue(parser,i);
									tmpMain = getAttributeValue(parser,i);
								}
								if(parser.getAttributeName(i).equals("exported")){
									if(getAttributeValue(parser,i).equals("false")){
										receiver += "$";
									}else{
										receiver += "*";
									}
								}
								if(parser.getAttributeName(i).equals("enabled")){
									if(getAttributeValue(parser,i).equals("false")){
										receiver += "!";
									}else{
										receiver += "";
									}
								}
							}
							receiver += tm+ "@@";
							break;
						}else if(parser.getName().equals("provider")){
							which = "provider";
							String tm = "";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									tm = getAttributeValue(parser,i);
									tmpMain = getAttributeValue(parser,i);
								}
								if(parser.getAttributeName(i).equals("exported")){
									if(getAttributeValue(parser,i).equals("false")){
										provider += "$";
									}else{
										provider += "*";
									}
								}
								if(parser.getAttributeName(i).equals("enabled")){
									if(getAttributeValue(parser,i).equals("false")){
										provider += "!";
									}else{
										provider += "";
									}
								}
							}
							provider += tm + "@@";
							break;
						}else if(parser.getName().equals("intent-filter")){
							switch(which){
								case "provider":
									provider = lastChar(provider)+"*@@";
									break;
								case "receiver":
									receiver = lastChar(receiver)+"*@@";
									break;
								case "service":
									service = lastChar(service)+"*@@";
									break;
								case "activity":
									activity = lastChar(activity)+"*@@";
									break;
							}
							
						}else if(parser.getName().equals("action")){
							which = "action";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									if(getAttributeValue(parser,i).equals("android.intent.action.MAIN")){
										application += tmpMain+"@@";
										break;
									}
									
								}
							}
							break;
						}else if(parser.getName().equals("manifest")){
							which = "manifest";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("package")){
									mpackage += getAttributeValue(parser,i)+"@@";
									break;
								}
								if(parser.getAttributeName(i).equals("VersionCode")){
									mpackage += getAttributeValue(parser,i)+"@@";
									break;
								}
								if(parser.getAttributeName(i).equals("android:VersionName")){
									mpackage += getAttributeValue(parser,i)+"@@";
									break;
								}
								//System.out.print(parser.getAttributeName(i));
							}
							break;
						}
					}
					
				}
			}
			String result = "";
			result += lastChar(mpackage) + "##";
			result += lastChar(application) + "##";
			result += lastChar(permission) + "##";
			result += lastChar(cookResult(activity)) + "##";
			result += lastChar(cookResult(service)) + "##";
			result += lastChar(cookResult(receiver)) + "##";
			result += lastChar(cookResult(provider));
			
			log(result);
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static String cookResult(String str){
		String[] t = str.split("@@");
		String r = t[0]+"@@";
		for(int i=1;i<t.length;i++){
			if(t[i].indexOf("$")!=-1)continue;
			if(t[i].indexOf("*")!=-1){
				r += t[i].replace("*", "") +"@@";
			}
		}
		return r;
	}
	//del @@
	private static String lastChar(String s){
		if(s.length()>2)
			return s.substring(0, s.length()-2);
		return "";
	}
	
	private static void dumpXml(AXmlResourceParser parser){
		try{
			
			String result = "";
			while (true) {
				int type=parser.next();
				if (type==XmlPullParser.END_DOCUMENT) {
					log(result);
					break;
				}
				switch (type) {
					case XmlPullParser.START_DOCUMENT:
					{
						result += "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
						break;
					}
					case XmlPullParser.START_TAG:
					{
						result += "<"+getNamespacePrefix(parser.getPrefix())+parser.getName();
						
						int namespaceCountBefore=parser.getNamespaceCount(parser.getDepth()-1);
						int namespaceCount=parser.getNamespaceCount(parser.getDepth());
						for (int i=namespaceCountBefore;i!=namespaceCount;++i) {
							result += " xmlns:"+parser.getNamespacePrefix(i)+"=\""+parser.getNamespaceUri(i)+"\"";
						}
						for (int i=0;i!=parser.getAttributeCount();++i) {
							result += " "+getNamespacePrefix(parser.getAttributePrefix(i))+parser.getAttributeName(i)+"=\""+getAttributeValue(parser,i)+"\"";
						}
						result += ">";
						break;
					}
					case XmlPullParser.END_TAG:
					{
						result += "</"+getNamespacePrefix(parser.getPrefix())+parser.getName()+">\r\n";
						break;
					}
					case XmlPullParser.TEXT:
					{
						result += parser.getText();
						break;
					}
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static String permissionC(String permission){
		switch(permission){
		case "android.permission.SEND_SMS":
			return " ���Ͷ���"+critical;
		case "android.permission.CALL_PHONE":
			return " ��绰"+critical;
		case "android.permission.CAMERA":
			return " ����ͷ"+critical;
		case "android.permission.RECORD_AUDIO":
			return " ¼��"+critical;
		case "android.permission.READ_CONTACTS":
			return " ��ȡͨѶ¼"+critical;
		case "android.permission.READ_SMS":
			return " ��ȡ����"+critical;
		case "android.permission.READ_PHONE_STATE":
			return " ��������"+critical;
		case "android.permission.PROCESS_OUTGOING_CALLS":
			return " ���ȥ��"+critical;
		case "android.permission.ACCESS_FINE_LOCATION":
		case "android.permission.ACCESS_COARSE_LOCATION":
		case "android.permission.ACCESS_GPS":
		case "android.permission.ACCESS_LOCATION":
			return " GPS"+critical;
		case "android.permission.RECEIVE_SMS":
			return " ���ն���"+critical;
		case "android.permission.VIBRATE":
			return " ��"+critical;
		case "com.android.browser.permission.READ_HISTORY_BOOKMARKS":
			return " ��������ղؼ�"+critical;
		case "com.android.browser.permission.WRITE_HISTORY_BOOKMARKS":
			return " д������ղؼ�"+critical;
		case "android.permission.RECEIVE_BOOT_COMPLETED":
			return " ��������"+critical;
		}
		return "";
	}
	
	private static String getNamespacePrefix(String prefix) {
		if (prefix==null || prefix.length()==0) {
			return "";
		}
		return prefix+":";
	}
	
	private static String getAttributeValue(AXmlResourceParser parser,int index) {
		int type=parser.getAttributeValueType(index);
		int data=parser.getAttributeValueData(index);
		if (type==TypedValue.TYPE_STRING) {
			return parser.getAttributeValue(index);
		}
		if (type==TypedValue.TYPE_ATTRIBUTE) {
			return String.format("?%s%08X",getPackage(data),data);
		}
		if (type==TypedValue.TYPE_REFERENCE) {
			return String.format("@%s%08X",getPackage(data),data);
		}
		if (type==TypedValue.TYPE_FLOAT) {
			return String.valueOf(Float.intBitsToFloat(data));
		}
		if (type==TypedValue.TYPE_INT_HEX) {
			return String.format("0x%08X",data);
		}
		if (type==TypedValue.TYPE_INT_BOOLEAN) {
			return data!=0?"true":"false";
		}
		if (type==TypedValue.TYPE_DIMENSION) {
			return Float.toString(complexToFloat(data))+
				DIMENSION_UNITS[data & TypedValue.COMPLEX_UNIT_MASK];
		}
		if (type==TypedValue.TYPE_FRACTION) {
			return Float.toString(complexToFloat(data))+
				FRACTION_UNITS[data & TypedValue.COMPLEX_UNIT_MASK];
		}
		if (type>=TypedValue.TYPE_FIRST_COLOR_INT && type<=TypedValue.TYPE_LAST_COLOR_INT) {
			return String.format("#%08X",data);
		}
		if (type>=TypedValue.TYPE_FIRST_INT && type<=TypedValue.TYPE_LAST_INT) {
			return String.valueOf(data);
		}
		return String.format("<0x%X, type 0x%02X>",data,type);
	}
	
	private static String getPackage(int id) {
		if (id>>>24==1) {
			return "android:";
		}
		return "";
	}

	private static void log(String format,Object...arguments) {
		System.out.printf(format,arguments);
		System.out.println();
	}
	
	/////////////////////////////////// ILLEGAL STUFF, DONT LOOK :)
	
	public static float complexToFloat(int complex) {
		return (float)(complex & 0xFFFFFF00)*RADIX_MULTS[(complex>>4) & 3];
	}
	
	private static final float RADIX_MULTS[]={
		0.00390625F,3.051758E-005F,1.192093E-007F,4.656613E-010F
	};
	private static final String DIMENSION_UNITS[]={
		"px","dip","sp","pt","in","mm","",""
	};
	private static final String FRACTION_UNITS[]={
		"%","%p","","","","","",""
	};
}