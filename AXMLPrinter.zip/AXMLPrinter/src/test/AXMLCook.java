/*
 * Copyright 2008 Android4ME
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *	 http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package test;

import java.io.File;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.xmlpull.v1.XmlPullParser;
import android.content.res.AXmlResourceParser;
import android.util.TypedValue;

public class AXMLCook {
	static String critical = "***";
	static String DEFAULT_XML = "AndroidManifest.xml";
	public static void main(String[] arguments) {
		try {
			String filename = "";
			if(arguments.length==2){
				if(arguments[0]=="-a"){
					filename = arguments[1];
				}else{
					filename = arguments[0];
				}
				dumpXml(filename);
				return;
			}else if(arguments.length==1){
				filename = arguments[0];
			}else{
				log("Usage: java -jar apkcook.jar test.apk [-a >result.txt]");
				return;
			}
			File apkFile = new File(filename);
			ZipFile file = new ZipFile(apkFile, ZipFile.OPEN_READ);
			ZipEntry entry = file.getEntry(DEFAULT_XML);
			
			AXmlResourceParser parser=new AXmlResourceParser();
			parser.open(file.getInputStream(entry));
			String mpackage = "����: ";
			String permission = "permission�б�: \n";
			String activity = "activity�б�: \n";
			String service = "service�б�: \n";
			String receiver = "receiver�б�: (��̬ע��registerReceiver���ݸ㲻��)\n";
			String provider = "provider�б�: \n";
			String application = "application: ###\n";
			
			String which = "";
			
			while (true) {
				int type=parser.next();
				if (type==XmlPullParser.END_DOCUMENT) {
					break;
				}
				switch (type) {
					
					case XmlPullParser.START_TAG:
					{
						if(parser.getName().equals("application")){
							boolean debuggable = false;
							boolean allowbackup = true;
							which = "application";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									application = application.replace("###", getAttributeValue(parser,i));
								}
								if(parser.getAttributeName(i).equals("debuggable")){
									if(getAttributeValue(parser,i).equals("true")){
										debuggable = true;
									}
								}
								if(parser.getAttributeName(i).equals("allowbackup")){
									if(getAttributeValue(parser,i).equals("false")){
										allowbackup = false;
									}
								}
							}
							application = application.replace("###", "none");
							if(debuggable){
								application += "�ɵ���: true"+critical + "\n";
							}else{
								application += "�ɵ���: false\n";
							}
							if(allowbackup){
								application += "�ɱ���: true"+critical + "\n";
							}else{
								application += "�ɱ���: false\n";
							}
							break;
						}
						if(parser.getName().equals("uses-permission")){
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									String tmp = permissionC(getAttributeValue(parser,i));
									permission += getAttributeValue(parser,i) +tmp+ "\n";
								}
							}
							break;
						}
						if(parser.getName().equals("activity")){
							which = "activity";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									activity += getAttributeValue(parser,i) + "\n";
								}
								if(parser.getAttributeName(i).equals("exported")){
									if(getAttributeValue(parser,i).equals("true")){
										activity = lastChar(activity) + critical + "\n";
									}
								}
								if(parser.getAttributeName(i).equals("enabled")){
									if(getAttributeValue(parser,i).equals("false")){
										activity = lastChar(activity) + "δ����" + "\n";
									}
								}
							}
							break;
						}
						if(parser.getName().equals("service")){
							which = "service";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									service += getAttributeValue(parser,i) + "\n";
								}
								if(parser.getAttributeName(i).equals("exported")){
									if(getAttributeValue(parser,i).equals("true")){
										service = lastChar(service) + critical + "\n";
									}
								}
								if(parser.getAttributeName(i).equals("enabled")){
									if(getAttributeValue(parser,i).equals("false")){
										service = lastChar(service) + "δ����" + "\n";
									}
								}
							}
							break;
						}
						if(parser.getName().equals("receiver")){
							which = "receiver";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									receiver += getAttributeValue(parser,i) + "\n";
								}
								if(parser.getAttributeName(i).equals("exported")){
									if(getAttributeValue(parser,i).equals("true")){
										receiver = lastChar(receiver) + critical + "\n";
									}
								}
								if(parser.getAttributeName(i).equals("enabled")){
									if(getAttributeValue(parser,i).equals("false")){
										receiver = lastChar(receiver) + "δ����" + "\n";
									}
								}
							}
							break;
						}
						if(parser.getName().equals("provider")){
							which = "provider";
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("name")){
									provider += getAttributeValue(parser,i) + "\n";
								}
								if(parser.getAttributeName(i).equals("exported")){
									if(getAttributeValue(parser,i).equals("true")){
										provider = lastChar(provider) + critical + "\n";
									}
								}
								if(parser.getAttributeName(i).equals("enabled")){
									if(getAttributeValue(parser,i).equals("false")){
										provider = lastChar(provider) + "δ����" + "\n";
									}
								}
							}
							break;
						}
						
						if(parser.getName().equals("intent-filter")){
							switch(which){
								case "provider":
									provider = lastChar(provider)+" ����"+critical+ "\n";
									break;
								case "receiver":
									receiver = lastChar(receiver)+" ����"+critical+ "\n";
									break;
								case "service":
									service = lastChar(service)+" ����"+critical+ "\n";
									break;
								case "activity":
									activity = lastChar(activity)+" ����"+critical+ "\n";
									break;
							}
							
						}
						if(parser.getName().equals("manifest")){
							for (int i=0;i!=parser.getAttributeCount();++i) {
								if(parser.getAttributeName(i).equals("package")){
									mpackage += getAttributeValue(parser,i) + "\n";
									break;
								}
							}
							break;
						}
					}
					
				}
			}
			log(mpackage);
			log(application);
			log(permission);
			log(activity);
			log(service);
			log(receiver);
			log(provider);
			
			file.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static String lastChar(String s){
		if(s.length()>2)
			return s.substring(0, s.length()-1);
		return "";
	}
	
	private static void dumpXml(String filename){
		try{
			File apkFile = new File(filename);
			ZipFile file = new ZipFile(apkFile, ZipFile.OPEN_READ);
			ZipEntry entry = file.getEntry(DEFAULT_XML);
			
			AXmlResourceParser parser=new AXmlResourceParser();
			parser.open(file.getInputStream(entry));
			StringBuilder indent=new StringBuilder(10);
			final String indentStep="	";
			while (true) {
				int type=parser.next();
				if (type==XmlPullParser.END_DOCUMENT) {
					break;
				}
				switch (type) {
					case XmlPullParser.START_DOCUMENT:
					{
						log("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
						break;
					}
					case XmlPullParser.START_TAG:
					{
						log("%s<%s%s",indent,
							getNamespacePrefix(parser.getPrefix()),parser.getName());
						indent.append(indentStep);
						
						int namespaceCountBefore=parser.getNamespaceCount(parser.getDepth()-1);
						int namespaceCount=parser.getNamespaceCount(parser.getDepth());
						for (int i=namespaceCountBefore;i!=namespaceCount;++i) {
							log("%sxmlns:%s=\"%s\"",
								indent,
								parser.getNamespacePrefix(i),
								parser.getNamespaceUri(i));
						}
						
						for (int i=0;i!=parser.getAttributeCount();++i) {
							log("%s%s%s=\"%s\"",indent,
								getNamespacePrefix(parser.getAttributePrefix(i)),
								parser.getAttributeName(i),
								getAttributeValue(parser,i));
						}
						log("%s>",indent);
						break;
					}
					case XmlPullParser.END_TAG:
					{
						indent.setLength(indent.length()-indentStep.length());
						log("%s</%s%s>",indent,
							getNamespacePrefix(parser.getPrefix()),
							parser.getName());
						break;
					}
					case XmlPullParser.TEXT:
					{
						log("%s%s",indent,parser.getText());
						break;
					}
				}
			}
			file.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static String permissionC(String permission){
		switch(permission){
		case "android.permission.SEND_SMS":
			return " ���Ͷ���"+critical;
		case "android.permission.CALL_PHONE":
			return " ��绰"+critical;
		case "android.permission.CAMERA":
			return " ����ͷ"+critical;
		case "android.permission.RECORD_AUDIO":
			return " ¼��"+critical;
		case "android.permission.READ_CONTACTS":
			return " ��ȡͨѶ¼"+critical;
		case "android.permission.READ_SMS":
			return " ��ȡ����"+critical;
		case "android.permission.READ_PHONE_STATE":
			return " ��������"+critical;
		case "android.permission.PROCESS_OUTGOING_CALLS":
			return " ���ȥ��"+critical;
		case "android.permission.ACCESS_FINE_LOCATION":
		case "android.permission.ACCESS_COARSE_LOCATION":
		case "android.permission.ACCESS_GPS":
		case "android.permission.ACCESS_LOCATION":
			return " GPS"+critical;
		case "android.permission.RECEIVE_SMS":
			return " ���ն���"+critical;
		case "android.permission.VIBRATE":
			return " ��"+critical;
		case "com.android.browser.permission.READ_HISTORY_BOOKMARKS":
			return " ��������ղؼ�"+critical;
		case "com.android.browser.permission.WRITE_HISTORY_BOOKMARKS":
			return " д������ղؼ�"+critical;
		case "android.permission.RECEIVE_BOOT_COMPLETED":
			return " ��������"+critical;
		}
		return "";
	}
	
	private static String getNamespacePrefix(String prefix) {
		if (prefix==null || prefix.length()==0) {
			return "";
		}
		return prefix+":";
	}
	
	private static String getAttributeValue(AXmlResourceParser parser,int index) {
		int type=parser.getAttributeValueType(index);
		int data=parser.getAttributeValueData(index);
		if (type==TypedValue.TYPE_STRING) {
			return parser.getAttributeValue(index);
		}
		if (type==TypedValue.TYPE_ATTRIBUTE) {
			return String.format("?%s%08X",getPackage(data),data);
		}
		if (type==TypedValue.TYPE_REFERENCE) {
			return String.format("@%s%08X",getPackage(data),data);
		}
		if (type==TypedValue.TYPE_FLOAT) {
			return String.valueOf(Float.intBitsToFloat(data));
		}
		if (type==TypedValue.TYPE_INT_HEX) {
			return String.format("0x%08X",data);
		}
		if (type==TypedValue.TYPE_INT_BOOLEAN) {
			return data!=0?"true":"false";
		}
		if (type==TypedValue.TYPE_DIMENSION) {
			return Float.toString(complexToFloat(data))+
				DIMENSION_UNITS[data & TypedValue.COMPLEX_UNIT_MASK];
		}
		if (type==TypedValue.TYPE_FRACTION) {
			return Float.toString(complexToFloat(data))+
				FRACTION_UNITS[data & TypedValue.COMPLEX_UNIT_MASK];
		}
		if (type>=TypedValue.TYPE_FIRST_COLOR_INT && type<=TypedValue.TYPE_LAST_COLOR_INT) {
			return String.format("#%08X",data);
		}
		if (type>=TypedValue.TYPE_FIRST_INT && type<=TypedValue.TYPE_LAST_INT) {
			return String.valueOf(data);
		}
		return String.format("<0x%X, type 0x%02X>",data,type);
	}
	
	private static String getPackage(int id) {
		if (id>>>24==1) {
			return "android:";
		}
		return "";
	}

	private static void log(String format,Object...arguments) {
		System.out.printf(format,arguments);
		System.out.println();
	}
	
	/////////////////////////////////// ILLEGAL STUFF, DONT LOOK :)
	
	public static float complexToFloat(int complex) {
		return (float)(complex & 0xFFFFFF00)*RADIX_MULTS[(complex>>4) & 3];
	}
	
	private static final float RADIX_MULTS[]={
		0.00390625F,3.051758E-005F,1.192093E-007F,4.656613E-010F
	};
	private static final String DIMENSION_UNITS[]={
		"px","dip","sp","pt","in","mm","",""
	};
	private static final String FRACTION_UNITS[]={
		"%","%p","","","","","",""
	};
}